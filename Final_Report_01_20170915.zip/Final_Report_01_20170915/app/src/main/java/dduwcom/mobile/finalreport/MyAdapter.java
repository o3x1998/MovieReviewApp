package dduwcom.mobile.finalreport;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;

public class MyAdapter extends BaseAdapter {
    private Context context;
    private int layout;
    private ArrayList<MyData> myDataList;
    private LayoutInflater layoutInflater;

    public MyAdapter(Context context, int layout, ArrayList<MyData> myDataList) {
        this.context = context;
        this.layout = layout;
        this.myDataList = myDataList;
        layoutInflater = (LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public int getCount() {
        return myDataList.size();
    }

    @Override
    public Object getItem(int pos) {
        return myDataList.get(pos);
    }

    @Override
    public long getItemId(int pos) {
        return myDataList.get(pos).get_id();
    }

    @Override
    public View getView(int pos, View view, ViewGroup viewGroup) {
        final  int position = pos;

        if (view == null) {
            view = layoutInflater.inflate(layout, viewGroup, false);
        }

        ImageView imageView = (ImageView)view.findViewById(R.id.imageView);
        TextView textGpa = (TextView)view.findViewById(R.id.textViewGpa);
        TextView textTitle = (TextView)view.findViewById(R.id.textViewTitle);
        TextView textDirector = (TextView)view.findViewById(R.id.textViewDirector);

        imageView.setImageResource(myDataList.get(pos).getImg());
        textGpa.setText(myDataList.get(pos).getGpa());
        textTitle.setText(myDataList.get(pos).getTitle());
        textDirector.setText(myDataList.get(pos).getDirector());

        return view;
    }
}
