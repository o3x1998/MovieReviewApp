package dduwcom.mobile.finalreport;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

public class MovieDBHelper extends SQLiteOpenHelper {
    final static String TAG = "MovieDBHelper";

    final static String DB_NAME = "movies.db";
    public final static String TABLE_NAME = "movie_table";

    public final static String COL_ID = "_id";
    public final static String COL_TITLE = "title";
    public final static String COL_ACTOR = "actor";
    public final static String COL_DIRECTOR = "director";
    public final static String COL_GPA = "gpa";
    public final static String COL_PLOT = "plot";
    public final static String COL_RELEASE_DATE = "release_date";
    public final static String COL_IMG = "img";

    public MovieDBHelper(Context context) {
        super(context, DB_NAME, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String sql = "CREATE TABLE " + TABLE_NAME + " (" + COL_ID + " integer primary key autoincrement, " +
                COL_TITLE + " TEXT, " + COL_ACTOR + " TEXT, " + COL_DIRECTOR + " TEXT, " + COL_GPA + " TEXT, "
                + COL_PLOT + " TEXT, " +  COL_RELEASE_DATE + " TEXT, " + COL_IMG + " integer)";
        Log.d(TAG, sql);
        db.execSQL(sql);

        db.execSQL("insert into " + TABLE_NAME + " values (null, '아이언맨', '로버트 다우니 주니어외', '존 파브로', '8.91점', '슈퍼히어로 아이언맨', '080430', " + R.mipmap.poster + " );");
        db.execSQL("insert into " + TABLE_NAME + " values (null, '기생충', '송강호, 이선균, 조여정외', '봉준호', '9.10점', '기택네 가족이 박사장네 취업하며 생기는 이야기', '190530', " + R.mipmap.poster1 + ");");
        db.execSQL("insert into " + TABLE_NAME + " values (null, '악인전', '마동석, 김무열외', '이원태', '8.58점', '살인범을 잡기위해 경찰과 조폭이 손을 잡음', '190515', " + R.mipmap.poster2 + ");");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(db);
    }
}
