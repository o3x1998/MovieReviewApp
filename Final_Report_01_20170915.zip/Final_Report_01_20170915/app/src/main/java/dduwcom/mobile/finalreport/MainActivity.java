// 과제명: 영화 리뷰 앱
// 분반: 01 분반
// 학번: 20170915 성명: 김문정
// 제출일: 2019년 : 2019년 6월 26일

package dduwcom.mobile.finalreport;

import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    final static String TAG = "MainActivity";
    final int REQ_CODE = 100;
    final int UPDATE_CODE = 200;

    ListView listView;
    MyAdapter adapter;
    ArrayList<MyData> movieList = null;
    MovieDBHelper movieDBHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        listView = findViewById(R.id.listView);
        movieList = new ArrayList<MyData>();
        movieDBHelper = new MovieDBHelper(this);
        adapter = new MyAdapter(this, R.layout.activity_adapter, movieList);
        listView.setAdapter(adapter);

//        리스트뷰의 항목 롱클릭 처리
        listView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> adapterView, View view, int pos, long id) {
//                삭제 기능 작성 - 삭제 확인 대화상자 출력
                final int position = pos;

                AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                builder.setTitle("영화 삭제");
                builder.setMessage( movieList.get(position).getTitle() + "을(를) 삭제하시겠습니까?");
                builder.setPositiveButton("삭제", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
//                        DB 삭제 수행
                        SQLiteDatabase db = movieDBHelper.getWritableDatabase();
                        String whereClause = movieDBHelper.COL_ID + "=?";
                        String[] whereArgs = new String[] { String.valueOf(movieList.get(position).get_id()) };
                        db.delete(movieDBHelper.TABLE_NAME, whereClause, whereArgs);
                        movieDBHelper.close();

//                        새로운 DB 내용으로 리스트뷰 갱신
                        readAllMovies();
                        adapter.notifyDataSetChanged();

                        Toast.makeText(MainActivity.this, "영화가 삭제되었습니다.", Toast.LENGTH_SHORT).show();
                    }
                });
                builder.setNegativeButton("취소", null);
                builder.show();
                return true;
            }
        });

//        리스트뷰의 항목 클릭 처리
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int pos, long id) {
//                수정 기능 작성 - UpdateActivity 를 결과를 받아오는 형태로 호출
                Intent intent = new Intent(MainActivity.this, UpdateActivity.class);

//                intent 에 수정 대상 movieDto 정보를 put
//                MyData movieDto = movieList.get(pos);
//                intent.putExtra("movieDto", movieDto);
                intent.putExtra("movieDto", movieList.get(pos));

                startActivityForResult(intent, UPDATE_CODE);
            }
        });
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.menu_add:
                Intent intent = new Intent(MainActivity.this, AddActivity.class);
                startActivityForResult(intent, REQ_CODE);
                break;
            case R.id.menu_search:
                Intent intent2 = new Intent(MainActivity.this, SearchActivity.class);
                startActivity(intent2);
                break;
            case R.id.menu_introduce:
                AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                builder.setTitle("개발자 소개");
                builder.setMessage( "모바일소프트웨어(01)\n" + "20170915 김문정");
                builder.setPositiveButton("확인", null);
                builder.show();
                break;
            case R.id.menu_finish:
                AlertDialog.Builder builder2 = new AlertDialog.Builder(MainActivity.this);
                builder2.setTitle("앱 종료");
                builder2.setMessage( "앱을 종료하시겠습니까?");
                builder2.setPositiveButton("종료", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        finish();
                    }
                });
                builder2.setNegativeButton("취소", null);
                builder2.show();
                break;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onResume() {
        super.onResume();
        readAllMovies();
        adapter.notifyDataSetChanged();
    }

    private void readAllMovies() {
        movieList.clear();

        SQLiteDatabase db = movieDBHelper.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + MovieDBHelper.TABLE_NAME, null);

        while(cursor.moveToNext()) {
            long id = cursor.getLong(cursor.getColumnIndex(MovieDBHelper.COL_ID));
            String title = cursor.getString(cursor.getColumnIndex(MovieDBHelper.COL_TITLE));
            String actor = cursor.getString(cursor.getColumnIndex(MovieDBHelper.COL_ACTOR));
            String director = cursor.getString(cursor.getColumnIndex(MovieDBHelper.COL_DIRECTOR));
            String gpa = cursor.getString(cursor.getColumnIndex(MovieDBHelper.COL_GPA));
            String plot = cursor.getString(cursor.getColumnIndex(MovieDBHelper.COL_PLOT));
            String release_date = cursor.getString(cursor.getColumnIndex(MovieDBHelper.COL_RELEASE_DATE));
            int img = cursor.getInt(cursor.getColumnIndex(MovieDBHelper.COL_IMG));
            movieList.add ( new MyData (id, title, actor, director, gpa, plot, release_date, img) );
        }

        cursor.close();
        movieDBHelper.close();
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == REQ_CODE) {  // AddActivity 호출 후 결과 확인
            switch(resultCode) {
                case RESULT_OK:
                    Toast.makeText(this, "영화 추가 완료", Toast.LENGTH_SHORT).show();
                    break;
                case RESULT_CANCELED:
                    Toast.makeText(this, "영화 추가 취소", Toast.LENGTH_SHORT).show();
                    break;
            }
        } else if (requestCode == UPDATE_CODE) {    // UpdateActivity 호출 후 결과 확인
            switch(resultCode) {
                case RESULT_OK:
                    Toast.makeText(this, "영화 수정 완료", Toast.LENGTH_SHORT).show();
                    break;
                case RESULT_CANCELED:
                    Toast.makeText(this, "영화 수정 취소", Toast.LENGTH_SHORT).show();
                    break;
            }
        }
    }
}
