package dduwcom.mobile.finalreport;

import android.content.DialogInterface;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.preference.DialogPreference;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class SearchActivity extends AppCompatActivity {
    EditText editText;
    MovieDBHelper movieDBHelper;

    MyData movieDto;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search);

        editText = findViewById(R.id.editText);

        movieDBHelper = new MovieDBHelper(this);
    }

    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btn_enter:
                if (editText.getText().toString().equals("")) {
                    Toast.makeText(this, "영화 제목을 입력하세요!", Toast.LENGTH_SHORT).show();
                    break;
                }
                else {
                    String result = "";

                    SQLiteDatabase db = movieDBHelper.getWritableDatabase();
                    Cursor cursor = db.rawQuery("SELECT * FROM "
                            + MovieDBHelper.TABLE_NAME + " WHERE title='" + editText.getText().toString() + "';", null);

                    while (cursor.moveToNext()) {
                        String title = cursor.getString(cursor.getColumnIndex(MovieDBHelper.COL_TITLE));
                        String actor = cursor.getString(cursor.getColumnIndex(MovieDBHelper.COL_ACTOR));
                        String director = cursor.getString(cursor.getColumnIndex(MovieDBHelper.COL_DIRECTOR));
                        String gpa = cursor.getString(cursor.getColumnIndex(MovieDBHelper.COL_GPA));

                        result += "영화 제목 : " + title + "\n주연 : " + actor + "\n감독 : " + director + "\n평점 : " + gpa;
                    }

                    if(result.equals("")) {
                        Toast.makeText(this, "영화 정보를 찾을 수 없습니다!", Toast.LENGTH_SHORT).show();
                        movieDBHelper.close();
                        cursor.close();
                        break;
                    }
                    else {
                        AlertDialog.Builder builder = new AlertDialog.Builder(SearchActivity.this);
                        builder.setTitle("영화 정보");
                        builder.setMessage(result);
                        builder.setPositiveButton("확인", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                finish();
                            }
                        });
                        builder.show();
                        movieDBHelper.close();
                        cursor.close();
                        break;
                    }
                }
            case R.id.btn_cancel:
                Toast.makeText(this, "영화 검색을 취소했습니다", Toast.LENGTH_SHORT).show();
                finish();
                break;
        }
    }
}
