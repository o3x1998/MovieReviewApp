package dduwcom.mobile.finalreport;

import android.content.ContentValues;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

public class UpdateActivity extends AppCompatActivity {
    EditText etTitle;
    EditText etActor;
    EditText etDirector;
    EditText etGpa;
    EditText etPlot;
    EditText etReleaseDate;
    ImageView imageView;

    MovieDBHelper movieDBHelper;

    MyData movieDto;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update);

        etTitle = findViewById(R.id.etTitle);
        etActor = findViewById(R.id.etActor);
        etDirector = findViewById(R.id.etDirector);
        etGpa = findViewById(R.id.etGpa);
        etPlot = findViewById(R.id.etPlot);
        etReleaseDate = findViewById(R.id.etReleaseDate);
        imageView = findViewById(R.id.imageView);

        movieDBHelper = new MovieDBHelper(this);

        Intent intent = getIntent();
        movieDto = (MyData)((Intent) intent).getSerializableExtra("movieDto");

//        MainActivity에서 전달한 intent를 통해 movieDto추출
        etTitle.setText(movieDto.getTitle());
        etActor.setText(movieDto.getActor());
        etDirector.setText(movieDto.getDirector());
        etGpa.setText(movieDto.getGpa());
        etPlot.setText(movieDto.getPlot());
        etReleaseDate.setText(movieDto.getRelease_date());
        imageView.setImageResource(movieDto.getImg());
    }

    public void onClick(View v) {
        switch(v.getId()) {
            case R.id.btn_update:
                String title = etTitle.getText().toString();
                String actor = etActor.getText().toString();
                String director = etDirector.getText().toString();
                String gpa = etGpa.getText().toString();
                String plot = etPlot.getText().toString();
                String releaseDate = etReleaseDate.getText().toString();

                if (etTitle.getText().toString().equals("") || etActor.getText().toString().equals("") ||
                        etDirector.getText().toString().equals("") || etGpa.getText().toString().equals("") ||
                        etPlot.getText().toString().equals("") || etReleaseDate.getText().toString().equals(""))
                {
                    Toast.makeText(this, "미입력된 정보가 있습니다!", Toast.LENGTH_SHORT).show();
                    movieDBHelper.close();
                    break;
                }

                SQLiteDatabase db = movieDBHelper.getWritableDatabase();

                ContentValues value = new ContentValues();
                value.put(MovieDBHelper.COL_TITLE, title);
                value.put(MovieDBHelper.COL_ACTOR, actor);
                value.put(MovieDBHelper.COL_DIRECTOR, director);
                value.put(MovieDBHelper.COL_GPA, gpa);
                value.put(MovieDBHelper.COL_PLOT, plot);
                value.put(MovieDBHelper.COL_RELEASE_DATE, releaseDate);

                String whereClause =  MovieDBHelper.COL_ID + "=?";
                String[] whereArgs = new String[] {String.valueOf(movieDto.get_id())};

                long count = db.update(MovieDBHelper.TABLE_NAME, value, whereClause, whereArgs);

                if (count > 0) {
                    setResult(RESULT_OK, null);
                    movieDBHelper.close();
                    finish();
                } else {
                    Toast.makeText(this, "영화 수정 실패!", Toast.LENGTH_SHORT).show();
                    movieDBHelper.close();
                }
                Toast.makeText(this, "영화 정보가 수정되었습니다!", Toast.LENGTH_SHORT).show();
                break;
            case R.id.btn_cancel:
                setResult(RESULT_CANCELED);
                finish();
                break;
        }
    }
}
