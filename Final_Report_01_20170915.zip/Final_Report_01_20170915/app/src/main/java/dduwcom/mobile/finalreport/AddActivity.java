package dduwcom.mobile.finalreport;

import android.content.ContentValues;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import java.util.Random;

public class AddActivity extends AppCompatActivity {
    EditText etTitle;
    EditText etActor;
    EditText etDirector;
    EditText etGpa;
    EditText etPlot;
    EditText etReleaseDate;

    MovieDBHelper movieDBHelper;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add);

        etTitle = findViewById(R.id.etTitle);
        etActor = findViewById(R.id.etActor);
        etDirector = findViewById(R.id.etDirector);
        etGpa = findViewById(R.id.etGpa);
        etPlot = findViewById(R.id.etPlot);
        etReleaseDate = findViewById(R.id.etReleaseDate);

        movieDBHelper = new MovieDBHelper(this);
    }

    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btn_add:
                SQLiteDatabase db = movieDBHelper.getWritableDatabase();
                ContentValues value = new ContentValues();

                if (etTitle.getText().toString().equals("") || etActor.getText().toString().equals("") ||
                        etDirector.getText().toString().equals("") || etGpa.getText().toString().equals("") ||
                        etPlot.getText().toString().equals("") || etReleaseDate.getText().toString().equals(""))
                {
                    Toast.makeText(this, "영화 정보를 입력하세요!", Toast.LENGTH_SHORT).show();
                    movieDBHelper.close();
                    break;
                }

                value.put(MovieDBHelper.COL_TITLE, etTitle.getText().toString());
                value.put(MovieDBHelper.COL_ACTOR, etActor.getText().toString());
                value.put(MovieDBHelper.COL_DIRECTOR, etDirector.getText().toString());
                value.put(MovieDBHelper.COL_GPA, etGpa.getText().toString());
                value.put(MovieDBHelper.COL_PLOT, etPlot.getText().toString());
                value.put(MovieDBHelper.COL_RELEASE_DATE, etReleaseDate.getText().toString());

                Random random = new Random();
                int r = random.nextInt(3);
                switch (r) {
                    case 0:
                        value.put(MovieDBHelper.COL_IMG, R.mipmap.poster3);
                        break;
                    case 1:
                        value.put(MovieDBHelper.COL_IMG, R.mipmap.poster4);
                        break;
                    case 2:
                        value.put(MovieDBHelper.COL_IMG, R.mipmap.poster5);
                        break;
                }

                long count = db.insert(MovieDBHelper.TABLE_NAME, null, value);

                if (count > 0) {
                    Intent resultIntent = new Intent();
                    resultIntent.putExtra("title", etTitle.getText().toString());
                    resultIntent.putExtra("director", etDirector.getText().toString());
                    resultIntent.putExtra("gpa", etGpa.getText().toString());


                    setResult(RESULT_OK, resultIntent);

                    movieDBHelper.close();
                    finish();
                }
                else {
                    Toast.makeText(this, "새로운 영화 추가 실패!", Toast.LENGTH_SHORT).show();
                    movieDBHelper.close();
                }
                break;
            case R.id.btn_cancel:
                setResult(RESULT_CANCELED);
                finish();
                break;
        }
    }

}
