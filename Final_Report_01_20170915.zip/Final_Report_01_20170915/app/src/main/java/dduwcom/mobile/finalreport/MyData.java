package dduwcom.mobile.finalreport;

import java.io.Serializable;

public class MyData implements Serializable {
    private long _id;
    private String title;
    private String actor;
    private String director;
    private String gpa;
    private String plot;
    private String release_date;
    private int img;

    public MyData(long _id, String title, String actor, String director, String gpa, String plot, String release_date, int img) {
        this._id = _id;
        this.title = title;
        this.actor = actor;
        this.director = director;
        this.gpa = gpa;
        this.plot = plot;
        this.release_date = release_date;
        this.img = img;
    }

    public MyData(String title, String actor, String director, String gpa, String plot, String release_date, int img) {
        this.title = title;
        this.actor = actor;
        this.director = director;
        this.gpa = gpa;
        this.plot = plot;
        this.release_date = release_date;
        this.img = img;
    }

    public long get_id() {
        return _id;
    }

    public void set_id(long _id) {
        this._id = _id;
    }


    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getActor() {
        return actor;
    }

    public void setActor(String actor) {
        this.actor = actor;
    }

    public String getDirector() {
        return director;
    }

    public void setDirector(String director) {
        this.director = director;
    }

    public String getGpa() {
        return gpa;
    }

    public void setGpa(String gpa) {
        this.gpa = gpa;
    }

    public String getPlot() {
        return plot;
    }

    public void setPlot(String plot) {
        this.plot = plot;
    }

    public String getRelease_date() {
        return release_date;
    }

    public void setRelease_date(String release_date) {
        this.release_date = release_date;
    }

    public int getImg() {
        return img;
    }

    public void setImg(int img) {
        this.img = img;
    }
}
